
package com.example.android.cheesy;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This app is a quiz about cheese that asks 4 questions and displays number correct onSubmit.
 */
public class MainActivity extends AppCompatActivity {

    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the submitAnswer button is clicked.
     */
    public void submitAnswers(View view) {

        /**
         * name field
         */
        EditText playerName = (EditText) findViewById(R.id.player_name);
        String name = playerName.getText().toString();

        /**
         * Checkbox options for Blue Cheese questions here
         */

        CheckBox blueCheeseCheckBox1 = (CheckBox) findViewById(R.id.blue_cheese_1_checkbox);
        boolean selectFoodColoring = blueCheeseCheckBox1.isChecked();
        CheckBox blueCheeseCheckBox2 = (CheckBox) findViewById(R.id.blue_cheese_2_checkbox);
        boolean selectAddMold = blueCheeseCheckBox2.isChecked();
        CheckBox blueCheeseCheckBox3 = (CheckBox) findViewById(R.id.blue_cheese_3_checkbox);
        boolean selectAddOxygen = blueCheeseCheckBox3.isChecked();
        CheckBox blueCheeseCheckBox4 = (CheckBox) findViewById(R.id.blue_cheese_4_checkbox);
        boolean selectBlueFairies = blueCheeseCheckBox4.isChecked();
        CheckBox swissCheeseCheckBox1 = (CheckBox) findViewById(R.id.swiss_1_checkbox);
        boolean selectBacteriaCultures = swissCheeseCheckBox1.isChecked();
        CheckBox swissCheeseCheckBox2 = (CheckBox) findViewById(R.id.swiss_2_checkbox);
        boolean selectAirPockets = swissCheeseCheckBox2.isChecked();
        CheckBox swissCheeseCheckBox3 = (CheckBox) findViewById(R.id.swiss_3_checkbox);
        boolean selectMiceEat = swissCheeseCheckBox3.isChecked();
        CheckBox swissCheeseCheckBox4 = (CheckBox) findViewById(R.id.swiss_4_checkbox);
        boolean selectCheeseHoleFairies = swissCheeseCheckBox4.isChecked();

        /** Radio Buttons French cheese here */

        // question 2 option 1
        RadioButton question2A = findViewById(R.id.french_cheese_1_radio);
        // Is the button now checked?
        boolean question2aChecked = question2A.isChecked();

        // question 2 option 2
        RadioButton question2B = findViewById(R.id.french_cheese_2_radio);
        // Is the button now checked?
        boolean question2bChecked = question2B.isChecked();

        // question 2 option 3
        RadioButton question2C = findViewById(R.id.french_cheese_3_radio);
        // Is the button now checked?
        boolean question2cChecked = question2C.isChecked();

        // question 2 option 4
        RadioButton question2D = findViewById(R.id.french_cheese_4_radio);
        // Is the button now checked?
        boolean question2dChecked = question2D.isChecked();

        /** Radio Buttons Goat's cheese here */

        // question 4 option 1
        RadioButton question4A = findViewById(R.id.goats_milk_1_radio);
        // Is the button now checked?
        boolean question4aChecked = question4A.isChecked();

        // question 4 option 2
        RadioButton question4B = findViewById(R.id.goats_milk_2_radio);
        // Is the button now checked?
        boolean question4bChecked = question4B.isChecked();

        int finalScore = calculateScore(selectAddMold, selectAddOxygen, selectAirPockets, selectBacteriaCultures, selectBlueFairies, selectCheeseHoleFairies, selectFoodColoring, selectMiceEat, question2aChecked, question2bChecked, question2cChecked, question2dChecked, question4aChecked, question4bChecked);

        if (score == 6) {
            // Show congratulations message as a toast
            Toast.makeText(this, name + ", YOU ARE CHEESY! Your score: " + finalScore + " All of your answers are correct", Toast.LENGTH_SHORT).show();
            return;
        } else if (score == 5) {
            // Show almost message as a toast
            Toast.makeText(this, name + ", YOU ARE ALMOST CHEESY! " + finalScore + " of your answers are correct", Toast.LENGTH_SHORT).show();
            return;

        } else if (score == 4) {
            // Show almost message as a toast
            Toast.makeText(this, name + ", YOU ARE ALMOST CHEESY! " + finalScore + " of your answers are correct", Toast.LENGTH_SHORT).show();
            return;

        } else if (score == 3) {
            // Show almost message as a toast
            Toast.makeText(this, name + ", YOU ARE ALMOST CHEESY! " + finalScore + " of your answers are correct", Toast.LENGTH_SHORT).show();
            return;

        } else if (score == 2) {
            // Show kind of message as a toast
            Toast.makeText(this, name + ", YOU ARE KIND OF CHEESY! " + finalScore + " of your answers are correct", Toast.LENGTH_SHORT).show();
            return;


        } else if (score == 1) {
            // Show sort of message as a toast
            Toast.makeText(this, name + ", YOU ARE SORT OF CHEESY! " + finalScore + " of your answers are correct", Toast.LENGTH_SHORT).show();
            return;


        } else if (score == 0) {
            // Show not message as a toast
            Toast.makeText(this, name + ", YOU ARE NOT CHEESY! " + finalScore + " of your answers are correct", Toast.LENGTH_SHORT).show();
            return;
        }

    }


    /**
     * Calculate Score of quiz when submitAnswer button clicked
     */
    private int calculateScore(boolean selectAddMold, boolean selectAddOxygen,
                               boolean selectAirPockets, boolean selectBacteriaCultures, boolean selectBlueFairies,
                               boolean selectCheeseHoleFairies, boolean selectFoodColoring, boolean selectMiceEat,
                               boolean question2aChecked, boolean question2bChecked, boolean question2cChecked,
                               boolean question2dChecked, boolean question4aChecked, boolean question4bChecked) {
        score = 0;

//Question 1 CheckBox 1 point per correct box selected

        if (selectAddMold) {
            score = score + 1;
        }
        if (selectAddOxygen) {
            score = score + 1;
        }
        if (selectFoodColoring) {
            score = score;
        }
        if (selectBlueFairies) {
            score = score;
        }
//Question 2 RadioButton options 1 point for a correct answer

        if (question2cChecked) {
            score = score + 1;
        }
        if (question2aChecked) {
            score = score;
        }
        if (question2bChecked) {
            score = score;
        }
        if (question2dChecked) {
            score = score;
        }

//Question 3 CheckBox 1 point per correct box selected

        if (selectBacteriaCultures) {
            score = score + 1;
        }
        if (selectAirPockets) {
            score = score + 1;
        }
        if (selectMiceEat) {
            score = score;
        }
        if (selectCheeseHoleFairies) {
            score = score;
        }

//Question 4 RadioButton options 1 point for a correct answer

        if (question4aChecked) {
            score = score + 1;
        } else score = score;

        return score;
    }
}

// End Calculate score
// End App




